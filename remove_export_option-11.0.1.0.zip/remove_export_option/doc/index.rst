Description
-----------
Remove the 'Export' option from the 'More' menu in the list view based on users group.
